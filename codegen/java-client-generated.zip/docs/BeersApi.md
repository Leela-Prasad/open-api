# BeersApi

All URIs are relative to *https://dev.example.com*

Method | HTTP request | Description
------------- | ------------- | -------------
[**deleteBeerByIdV1**](BeersApi.md#deleteBeerByIdV1) | **DELETE** /v1/beers/{beerId} | Delete Beer
[**getBeerByIdV1**](BeersApi.md#getBeerByIdV1) | **GET** /v1/beers/{beerId} | List Beer By Id
[**listBeersV1**](BeersApi.md#listBeersV1) | **GET** /v1/beers | List Beers
[**saveBeerV1**](BeersApi.md#saveBeerV1) | **POST** /v1/beers | New Beer
[**updateBeerByIdV1**](BeersApi.md#updateBeerByIdV1) | **PUT** /v1/beers/{beerId} | Update Beer

<a name="deleteBeerByIdV1"></a>
# **deleteBeerByIdV1**
> deleteBeerByIdV1(beerId)

Delete Beer

Delete Beer By Id

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.BeersApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();
// Configure HTTP basic authorization: BasicAuth
HttpBasicAuth BasicAuth = (HttpBasicAuth) defaultClient.getAuthentication("BasicAuth");
BasicAuth.setUsername("YOUR USERNAME");
BasicAuth.setPassword("YOUR PASSWORD");


BeersApi apiInstance = new BeersApi();
UUID beerId = new UUID(); // UUID | Beer Id
try {
    apiInstance.deleteBeerByIdV1(beerId);
} catch (ApiException e) {
    System.err.println("Exception when calling BeersApi#deleteBeerByIdV1");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **beerId** | [**UUID**](.md)| Beer Id |

### Return type

null (empty response body)

### Authorization

[BasicAuth](../README.md#BasicAuth)[JwtAuthToken](../README.md#JwtAuthToken)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="getBeerByIdV1"></a>
# **getBeerByIdV1**
> Beer getBeerByIdV1(beerId)

List Beer By Id

Get a single **Beer** by its Id value

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.BeersApi;


BeersApi apiInstance = new BeersApi();
UUID beerId = new UUID(); // UUID | Beer Id
try {
    Beer result = apiInstance.getBeerByIdV1(beerId);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling BeersApi#getBeerByIdV1");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **beerId** | [**UUID**](.md)| Beer Id |

### Return type

[**Beer**](Beer.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

<a name="listBeersV1"></a>
# **listBeersV1**
> BeerPagedList listBeersV1(pageNumber, pageSize)

List Beers

List All Beers in the system

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.BeersApi;


BeersApi apiInstance = new BeersApi();
Integer pageNumber = 1; // Integer | Page Number
Integer pageSize = 25; // Integer | Page Size
try {
    BeerPagedList result = apiInstance.listBeersV1(pageNumber, pageSize);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling BeersApi#listBeersV1");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **pageNumber** | **Integer**| Page Number | [optional] [default to 1]
 **pageSize** | **Integer**| Page Size | [optional] [default to 25]

### Return type

[**BeerPagedList**](BeerPagedList.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

<a name="saveBeerV1"></a>
# **saveBeerV1**
> saveBeerV1(body)

New Beer

Create a New Beer

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.BeersApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();
// Configure HTTP basic authorization: BasicAuth
HttpBasicAuth BasicAuth = (HttpBasicAuth) defaultClient.getAuthentication("BasicAuth");
BasicAuth.setUsername("YOUR USERNAME");
BasicAuth.setPassword("YOUR PASSWORD");


BeersApi apiInstance = new BeersApi();
Beer body = new Beer(); // Beer | 
try {
    apiInstance.saveBeerV1(body);
} catch (ApiException e) {
    System.err.println("Exception when calling BeersApi#saveBeerV1");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Beer**](Beer.md)|  |

### Return type

null (empty response body)

### Authorization

[BasicAuth](../README.md#BasicAuth)[JwtAuthToken](../README.md#JwtAuthToken)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: Not defined

<a name="updateBeerByIdV1"></a>
# **updateBeerByIdV1**
> updateBeerByIdV1(body, beerId)

Update Beer

Update Beer by Id

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.BeersApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();
// Configure HTTP basic authorization: BasicAuth
HttpBasicAuth BasicAuth = (HttpBasicAuth) defaultClient.getAuthentication("BasicAuth");
BasicAuth.setUsername("YOUR USERNAME");
BasicAuth.setPassword("YOUR PASSWORD");


BeersApi apiInstance = new BeersApi();
Beer body = new Beer(); // Beer | 
UUID beerId = new UUID(); // UUID | Beer Id
try {
    apiInstance.updateBeerByIdV1(body, beerId);
} catch (ApiException e) {
    System.err.println("Exception when calling BeersApi#updateBeerByIdV1");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Beer**](Beer.md)|  |
 **beerId** | [**UUID**](.md)| Beer Id |

### Return type

null (empty response body)

### Authorization

[BasicAuth](../README.md#BasicAuth)[JwtAuthToken](../README.md#JwtAuthToken)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: Not defined

