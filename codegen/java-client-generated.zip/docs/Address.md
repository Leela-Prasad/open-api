# Address

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**line1** | **String** |  |  [optional]
**city** | **String** |  |  [optional]
**stateCode** | [**StateCodeEnum**](#StateCodeEnum) | 2 Letter State Code |  [optional]
**zipCode** | **String** |  |  [optional]

<a name="StateCodeEnum"></a>
## Enum: StateCodeEnum
Name | Value
---- | -----
AP | &quot;AP&quot;
TN | &quot;TN&quot;
KA | &quot;KA&quot;
