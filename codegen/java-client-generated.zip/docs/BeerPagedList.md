# BeerPagedList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**content** | [**BeerList**](BeerList.md) |  |  [optional]
