# CustomersApi

All URIs are relative to *https://dev.example.com*

Method | HTTP request | Description
------------- | ------------- | -------------
[**deleteCustomerByIdV1**](CustomersApi.md#deleteCustomerByIdV1) | **DELETE** /v1/customers/{customerId} | Delete Customer
[**getCustomerByIdV1**](CustomersApi.md#getCustomerByIdV1) | **GET** /v1/customers/{customerId} | Get Customer By Id
[**listCustomersV1**](CustomersApi.md#listCustomersV1) | **GET** /v1/customers | List Customers
[**saveCustomerV1**](CustomersApi.md#saveCustomerV1) | **POST** /v1/customers | New Customer
[**updateCustomerByIdV1**](CustomersApi.md#updateCustomerByIdV1) | **PUT** /v1/customers/{customerId} | Update Customer

<a name="deleteCustomerByIdV1"></a>
# **deleteCustomerByIdV1**
> deleteCustomerByIdV1(customerId)

Delete Customer

Delete Customer By Id

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.CustomersApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();
// Configure HTTP basic authorization: BasicAuth
HttpBasicAuth BasicAuth = (HttpBasicAuth) defaultClient.getAuthentication("BasicAuth");
BasicAuth.setUsername("YOUR USERNAME");
BasicAuth.setPassword("YOUR PASSWORD");


CustomersApi apiInstance = new CustomersApi();
UUID customerId = new UUID(); // UUID | Customer Id
try {
    apiInstance.deleteCustomerByIdV1(customerId);
} catch (ApiException e) {
    System.err.println("Exception when calling CustomersApi#deleteCustomerByIdV1");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **customerId** | [**UUID**](.md)| Customer Id |

### Return type

null (empty response body)

### Authorization

[BasicAuth](../README.md#BasicAuth)[JwtAuthToken](../README.md#JwtAuthToken)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="getCustomerByIdV1"></a>
# **getCustomerByIdV1**
> Customer getCustomerByIdV1(customerId)

Get Customer By Id

Get a single **Customer** by its Id value

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.CustomersApi;


CustomersApi apiInstance = new CustomersApi();
UUID customerId = new UUID(); // UUID | Customer Id
try {
    Customer result = apiInstance.getCustomerByIdV1(customerId);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling CustomersApi#getCustomerByIdV1");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **customerId** | [**UUID**](.md)| Customer Id |

### Return type

[**Customer**](Customer.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

<a name="listCustomersV1"></a>
# **listCustomersV1**
> CustomerPagedList listCustomersV1(pageNumber, pageSize)

List Customers

List All Customers in the System

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.CustomersApi;


CustomersApi apiInstance = new CustomersApi();
Integer pageNumber = 1; // Integer | Page Number
Integer pageSize = 25; // Integer | Page Size
try {
    CustomerPagedList result = apiInstance.listCustomersV1(pageNumber, pageSize);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling CustomersApi#listCustomersV1");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **pageNumber** | **Integer**| Page Number | [optional] [default to 1]
 **pageSize** | **Integer**| Page Size | [optional] [default to 25]

### Return type

[**CustomerPagedList**](CustomerPagedList.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

<a name="saveCustomerV1"></a>
# **saveCustomerV1**
> saveCustomerV1(body)

New Customer

Create a New Customer

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.CustomersApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();
// Configure HTTP basic authorization: BasicAuth
HttpBasicAuth BasicAuth = (HttpBasicAuth) defaultClient.getAuthentication("BasicAuth");
BasicAuth.setUsername("YOUR USERNAME");
BasicAuth.setPassword("YOUR PASSWORD");


CustomersApi apiInstance = new CustomersApi();
Customer body = new Customer(); // Customer | 
try {
    apiInstance.saveCustomerV1(body);
} catch (ApiException e) {
    System.err.println("Exception when calling CustomersApi#saveCustomerV1");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Customer**](Customer.md)|  |

### Return type

null (empty response body)

### Authorization

[BasicAuth](../README.md#BasicAuth)[JwtAuthToken](../README.md#JwtAuthToken)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: Not defined

<a name="updateCustomerByIdV1"></a>
# **updateCustomerByIdV1**
> updateCustomerByIdV1(body, customerId)

Update Customer

Update Customer By Id

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.CustomersApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();
// Configure HTTP basic authorization: BasicAuth
HttpBasicAuth BasicAuth = (HttpBasicAuth) defaultClient.getAuthentication("BasicAuth");
BasicAuth.setUsername("YOUR USERNAME");
BasicAuth.setPassword("YOUR PASSWORD");


CustomersApi apiInstance = new CustomersApi();
Customer body = new Customer(); // Customer | 
UUID customerId = new UUID(); // UUID | Customer Id
try {
    apiInstance.updateCustomerByIdV1(body, customerId);
} catch (ApiException e) {
    System.err.println("Exception when calling CustomersApi#updateCustomerByIdV1");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Customer**](Customer.md)|  |
 **customerId** | [**UUID**](.md)| Customer Id |

### Return type

null (empty response body)

### Authorization

[BasicAuth](../README.md#BasicAuth)[JwtAuthToken](../README.md#JwtAuthToken)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: Not defined

