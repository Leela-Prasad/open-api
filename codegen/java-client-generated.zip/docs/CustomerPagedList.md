# CustomerPagedList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**content** | [**CustomerList**](CustomerList.md) |  |  [optional]
