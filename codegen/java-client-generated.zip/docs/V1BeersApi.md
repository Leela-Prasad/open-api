# V1BeersApi

All URIs are relative to *https://dev.example.com*

Method | HTTP request | Description
------------- | ------------- | -------------
[**getBeerByIdV1**](V1BeersApi.md#getBeerByIdV1) | **GET** /v1/beers/{beerId} | List Beer By Id

<a name="getBeerByIdV1"></a>
# **getBeerByIdV1**
> Beer getBeerByIdV1(beerId)

List Beer By Id

Get a single **Beer** by its Id value

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.V1BeersApi;


V1BeersApi apiInstance = new V1BeersApi();
UUID beerId = new UUID(); // UUID | Beer Id
try {
    Beer result = apiInstance.getBeerByIdV1(beerId);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling V1BeersApi#getBeerByIdV1");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **beerId** | [**UUID**](.md)| Beer Id |

### Return type

[**Beer**](Beer.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

